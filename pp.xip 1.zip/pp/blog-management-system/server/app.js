const express = require('express');
const connectToDatabase = require('./mongoconnect'); 

const app = express();
const PORT = 5000;

app.use(express.json());
app.use(express.static('public'));

connectToDatabase().then(db => {
  app.locals.db = db;

  // Optional test route
  app.get('/comments', async (req, res) => {
    const comments = await db.collection('comments').find().limit(5).toArray();
    res.json(comments);
  });

  // Routes
  const authRoutes = require('./routes/auth');
  const blogRoutes = require('./routes/blog');

  app.use('/api/auth', authRoutes);
  app.use('/api/blogs', blogRoutes);

  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error("❌ Failed to start server:", err);
});

