const { MongoClient } = require("mongodb");

const uri = "mongodb+srv://srinithya:<nithya>@cluster0.bwdttn.mongodb.net/?retryWrites=true&w=majority";

const client = new MongoClient(uri);

async function connectToDatabase() {
  try {
    await client.connect();
    console.log("MongoDB Connected ✅");
    return client.db("sample_mflix"); // or your own DB name
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
}
module.exports = connectToDatabase;
