const express = require('express');
const router = express.Router();

// Dummy blogs array (later we can replace this with database)
let blogs = [];

// Create a new blog
router.post('/', (req, res) => {
  const { title, content } = req.body;

  if (!title || !content) {
    return res.status(400).json({ message: 'Title and content are required.' });
  }

  const newBlog = {
    id: blogs.length + 1,
    title,
    content,
    createdAt: new Date()
  };

  blogs.push(newBlog);
  res.status(201).json({ message: 'Blog created successfully!', blog: newBlog });
});

// (Optional) Get all blogs - you can use this later for listing blogs
router.get('/', (req, res) => {
  res.json(blogs);
});

module.exports = router;
